package com.example.choisangah.realtonymony;

/**
 * Created by choisangah on 2017. 6. 15..
 */

public class Item {
    int id;
    String iname;
    String ibrand;
    String itone;
    String iSitelink;
    String iImglink;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIname() {
        return iname;
    }

    public void setIname(String iname) {
        this.iname = iname;
    }

    public String getIbrand() {
        return ibrand;
    }

    public void setIbrand(String ibrand) {
        this.ibrand = ibrand;
    }

    public String getItone() {
        return itone;
    }

    public void setItone(String itone) {
        this.itone = itone;
    }

    public String getiSitelink() {
        return iSitelink;
    }

    public void setiSitelink(String iSitelink) {
        this.iSitelink = iSitelink;
    }

    public String getiImglink() {
        return iImglink;
    }

    public void setiImglink(String iImglink) {
        this.iImglink = iImglink;
    }
}
